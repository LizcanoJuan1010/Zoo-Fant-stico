package Zoo_Fantastico.app.Creature;

public class Zone {
}
